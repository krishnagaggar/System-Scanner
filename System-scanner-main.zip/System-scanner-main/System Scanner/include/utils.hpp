#ifndef UTILS_HPP
#define UTILS_HPP

#include <string>

bool is_valid_ip(const std::string& ip);
std::string get_service_name(int port);

#endif // UTILS_HPP
